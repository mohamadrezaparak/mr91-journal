package com.mr91.journal;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.view.*;
import android.view.animation.*;
import android.graphics.drawable.GradientDrawable;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private final int BG=Color.rgb(8,13,24), CARD=Color.rgb(17,26,43), BLUE=Color.rgb(79,140,255), WHITE=Color.WHITE, MUTED=Color.rgb(151,166,190), GREEN=Color.rgb(37,190,130), RED=Color.rgb(245,83,100);
    private TradeDb db; private LinearLayout root, body; private boolean fa=true; private Uri pickedChart; private long outcomeId=-1;
    private static final int PICK_CHART=91;
    @Override public void onCreate(Bundle b){super.onCreate(b); db=new TradeDb(this); showHome();}
    private String s(String faText,String enText){return fa?faText:enText;}
    private TextView text(String value,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);t.setTypeface(null,bold?Typeface.BOLD:Typeface.NORMAL);t.setPadding(0,5,0,5);return t;}
    private LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private void base(String title){
        root=column(); GradientDrawable shell=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{Color.rgb(10,19,36),BG}); root.setBackground(shell); root.setPadding(20,18,20,16); root.setLayoutDirection(fa?View.LAYOUT_DIRECTION_RTL:View.LAYOUT_DIRECTION_LTR);
        TextView brand=text("MR91  /  JOURNAL",13,BLUE,true);root.addView(brand);
        LinearLayout top=row(); TextView h=text(title,25,WHITE,true);top.addView(h,new LinearLayout.LayoutParams(0,-2,1));
        Button lang=new Button(this);lang.setText(fa?"EN":"فا");lang.setTextColor(WHITE);lang.setBackgroundTintList(android.content.res.ColorStateList.valueOf(CARD));lang.setOnClickListener(v->{fa=!fa;showHome();});top.addView(lang);root.addView(top);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(false);scroll.setClipToPadding(false);body=column();body.setPadding(0,12,0,20);body.setLayoutDirection(fa?View.LAYOUT_DIRECTION_RTL:View.LAYOUT_DIRECTION_LTR);scroll.addView(body);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=row();nav.setPadding(0,10,0,0);
        nav.addView(navButton(s("داشبورد","Dashboard"),()->showHome()),new LinearLayout.LayoutParams(0,-2,1));
        nav.addView(navButton(s("معاملات","Trades"),()->showTrades()),new LinearLayout.LayoutParams(0,-2,1));
        nav.addView(navButton(s("ثبت معامله","New trade"),()->showForm()),new LinearLayout.LayoutParams(0,-2,1));
        root.addView(nav);setContentView(root);root.setAlpha(0f);root.animate().alpha(1f).setDuration(220).start();
    }
    private Button navButton(String label,Runnable r){Button b=new Button(this);b.setText(label);b.setTextSize(11);b.setAllCaps(false);b.setTextColor(WHITE);GradientDrawable shape=new GradientDrawable();shape.setColor(CARD);shape.setCornerRadius(22f);shape.setStroke(1,Color.rgb(38,57,84));b.setBackground(shape);b.setPadding(12,9,12,9);b.setOnTouchListener((v,e)->{if(e.getAction()==MotionEvent.ACTION_DOWN){v.animate().scaleX(.97f).scaleY(.97f).setDuration(90).start();}else if(e.getAction()==MotionEvent.ACTION_UP||e.getAction()==MotionEvent.ACTION_CANCEL){v.animate().scaleX(1f).scaleY(1f).setDuration(130).start();}return false;});b.setOnClickListener(v->r.run());return b;}
    private void card(View v){LinearLayout c=column();GradientDrawable shape=new GradientDrawable();shape.setColor(CARD);shape.setCornerRadius(24f);shape.setStroke(1,Color.rgb(31,47,71));c.setBackground(shape);c.setPadding(16,14,16,14);c.setElevation(5);c.addView(v);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=13;body.addView(c,p);animateIn(c,body.getChildCount()-1);} 
    private void animateIn(View v,int index){v.setAlpha(0f);v.setTranslationY(22f);v.animate().alpha(1f).translationY(0f).setStartDelay(Math.min(index*45,270)).setDuration(360).setInterpolator(new DecelerateInterpolator()).start();}
    private void showHome(){
        base(s("نمای کلی","Overview"));
        int total=db.count(), wins=db.wins(), losses=db.losses(), closed=wins+losses; double rate=closed==0?0:(wins*100.0/closed);
        card(text(s("مرکز فرماندهی معاملات","Trading command center"),18,WHITE,true));
        LinearLayout stats=row();
        stats.addView(metric(s("کل معاملات","Total trades"),""+total),new LinearLayout.LayoutParams(0,-2,1));
        stats.addView(metric(s("نرخ برد","Win rate"),String.format(Locale.US,"%.1f%%",rate)),new LinearLayout.LayoutParams(0,-2,1));
        stats.addView(metric(s("باز","Open"),""+Math.max(0,total-closed)),new LinearLayout.LayoutParams(0,-2,1));card(stats);
        LinearLayout outcomes=row();
        outcomes.addView(metric(s("بردها","Wins"),""+wins),new LinearLayout.LayoutParams(0,-2,1));
        outcomes.addView(metric(s("باخت‌ها","Losses"),""+losses),new LinearLayout.LayoutParams(0,-2,1));
        outcomes.addView(metric(s("سود/ضرر خالص","Net P/L"),String.format(Locale.US,"%.2f",db.totalPnl())),new LinearLayout.LayoutParams(0,-2,1));card(outcomes);
        card(text(s("شروع سریع","Quick actions"),17,WHITE,true));
        Button add=navButton(s("＋ ثبت معامله جدید","＋ Add new trade"),()->showForm());card(add);
        Button trades=navButton(s("مشاهده ژورنال معاملات","Open trade journal"),()->showTrades());card(trades);
        card(text(s("نسخه آزمایشی 1.3.0 — ذخیره‌سازی آفلاین روی دستگاه","Alpha 1.3.0 — offline local storage"),12,MUTED,false));
    }
    private View metric(String label,String value){LinearLayout x=column();x.addView(text(label,11,MUTED,false));x.addView(text(value,18,WHITE,true));return x;}
    private void showTrades(){
        base(s("ژورنال معاملات","Trade journal"));
        ArrayList<Trade> list=db.all(); if(list.isEmpty()){card(text(s("هنوز معامله‌ای ثبت نشده است. اولین معامله‌ات را اضافه کن.","No trades yet. Add your first trade."),15,MUTED,false));return;}
        for(Trade t:list){LinearLayout c=column();LinearLayout r=row();r.addView(text(t.symbol+"  ·  "+t.direction,17,WHITE,true),new LinearLayout.LayoutParams(0,-2,1));int col="WIN".equals(t.status)?GREEN:("LOSS".equals(t.status)?RED:BLUE);r.addView(text(t.status,12,col,true));c.addView(r);c.addView(text(s("حجم: ","Size: ")+safe(t.volume)+" "+safe(t.currency)+"   × "+safe(t.leverage),12,MUTED,false));c.addView(text(s("ورود: ","Entry: ")+safe(t.entryPrice)+"   |   "+s("خروج: ","Exit: ")+safe(t.exitPrice),12,MUTED,false));
            if("OPEN".equals(t.status)){LinearLayout actions=row();Button win=navButton(s("سود شد","WIN"),()->outcome(t.id,true));win.setTextColor(GREEN);Button loss=navButton(s("ضرر شد","LOSS"),()->outcome(t.id,false));loss.setTextColor(RED);actions.addView(win,new LinearLayout.LayoutParams(0,-2,1));actions.addView(loss,new LinearLayout.LayoutParams(0,-2,1));c.addView(actions);}
            if(t.pnl!=null)c.addView(text(s("نتیجه: ","P/L: ")+safe(t.pnl)+" "+safe(t.currency),13,col,true));
            Button del=navButton(s("حذف معامله","Delete trade"),()->new AlertDialog.Builder(this).setMessage(s("این معامله حذف شود؟","Delete this trade?")).setNegativeButton(s("لغو","Cancel"),null).setPositiveButton(s("حذف","Delete"),(d,w)->{db.delete(t.id);showTrades();}).show());c.addView(del);
            GradientDrawable tradeBg=new GradientDrawable();tradeBg.setColor(CARD);tradeBg.setCornerRadius(22f);tradeBg.setStroke(1,Color.rgb(31,47,71));c.setBackground(tradeBg);c.setPadding(15,13,15,13);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=12;body.addView(c,p);animateIn(c,body.getChildCount()-1);
        }
    }
    private String safe(String x){return x==null||x.trim().isEmpty()?"—":x;}
    private EditText field(String hint){EditText e=new EditText(this);e.setSingleLine(true);e.setInputType(android.text.InputType.TYPE_CLASS_TEXT);e.setHint(hint);e.setHintTextColor(MUTED);e.setTextColor(WHITE);e.setTextSize(14);e.setPadding(10,7,10,7);e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(BLUE));return e;}
    private EditText numberField(String hint){
        EditText e=field(hint);
        e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL | android.text.InputType.TYPE_NUMBER_FLAG_SIGNED);
        e.setKeyListener(android.text.method.DigitsKeyListener.getInstance("0123456789.,-"));
        return e;
    }
    private Double number(String raw){
        if(raw==null)return null;
        try { double d=Double.parseDouble(raw.trim().replace(",", ".").replace("٬","").replace("٫",".")); return Double.isFinite(d)?d:null; }
        catch(Exception ex){ return null; }
    }
    private boolean positive(String raw){ Double d=number(raw); return d!=null && d>0; }
    private void addField(String label,EditText e){body.addView(text(label,12,MUTED,true));body.addView(e);}
    private void showForm(){
        base(s("ثبت معامله جدید","New trade"));
        card(text(s("مشخصات معامله","Trade details"),17,WHITE,true));
        EditText symbol=field(s("مثلاً BTCUSDT","e.g. BTCUSDT"));addField(s("نام جفت‌ارز / نماد","Pair / symbol"),symbol);
        Spinner direction=new Spinner(this);String[] dirs=fa?new String[]{"خرید / Long","فروش / Short"}:new String[]{"Long","Short"};direction.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,dirs));body.addView(direction);
        EditText entry=numberField(s("قیمت ورود اصلی","Main entry price"));addField(s("قیمت ورود","Entry price"),entry);
        EditText exit=numberField(s("قیمت خروج (اختیاری)","Exit price (optional)"));addField(s("قیمت خروج","Exit price"),exit);
        EditText entry1=numberField("Entry 1"),entry2=numberField("Entry 2");addField("Entry 1",entry1);addField("Entry 2",entry2);
        EditText tp1=numberField("TP 1"),tp2=numberField("TP 2"),sl1=numberField("SL 1"),sl2=numberField("SL 2");
        addField("TP 1",tp1);addField("TP 2",tp2);addField("SL 1",sl1);addField("SL 2",sl2);
        EditText volume=numberField(s("حجم ورود","Position size"));addField(s("حجم ورود","Position size"),volume);
        Spinner currency=new Spinner(this);currency.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"USD","USDT","IRR","Toman"}));body.addView(currency);
        EditText leverage=numberField(s("مثلاً 5","e.g. 5"));addField(s("اهرم (مثلاً 5x)","Leverage (e.g. 5x)"),leverage);
        Button save=navButton(s("ذخیره معامله","Save trade"),()->{
            if(symbol.getText().toString().trim().isEmpty() || !positive(entry.getText().toString()) || !positive(volume.getText().toString())){
                new AlertDialog.Builder(this).setMessage(s("نماد الزامی است و قیمت ورود و حجم باید عدد مثبت باشند.","Symbol is required; entry price and size must be positive numbers.")).setPositiveButton("OK",null).show();return;
            }
            if(!exit.getText().toString().trim().isEmpty() && !positive(exit.getText().toString())){
                new AlertDialog.Builder(this).setMessage(s("قیمت خروج باید عدد مثبت باشد.","Exit price must be a positive number.")).setPositiveButton("OK",null).show();return;
            }
            if(!leverage.getText().toString().trim().isEmpty() && !positive(leverage.getText().toString())){
                new AlertDialog.Builder(this).setMessage(s("اهرم باید عدد مثبت باشد.","Leverage must be a positive number.")).setPositiveButton("OK",null).show();return;
            }
            Trade t=new Trade();t.symbol=symbol.getText().toString().trim().toUpperCase(Locale.ROOT);t.direction=direction.getSelectedItemPosition()==0?"LONG":"SHORT";t.entryPrice=entry.getText().toString();t.exitPrice=exit.getText().toString();t.entry1=entry1.getText().toString();t.entry2=entry2.getText().toString();t.tp1=tp1.getText().toString();t.tp2=tp2.getText().toString();t.sl1=sl1.getText().toString();t.sl2=sl2.getText().toString();t.volume=volume.getText().toString();t.currency=currency.getSelectedItem().toString().trim();t.leverage=leverage.getText().toString();t.createdAt=new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(new Date());db.insert(t);showTrades();
        });card(save);
    }
    private void outcome(long id,boolean win){
        outcomeId=id; pickedChart=null; final EditText pnl=numberField(s("میزان سود/ضرر","P/L amount")); final EditText reason=field(s("علت برد/باخت","Reason")),lesson=field(s("تجربه و درس معامله","Lesson learned"));
        LinearLayout form=column();form.setPadding(12,4,12,4);form.addView(pnl);form.addView(reason);form.addView(lesson);
        Button photo=navButton(s("＋ افزودن عکس چارت","＋ Attach chart image"),()->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK_CHART);});
        form.addView(photo);
        new AlertDialog.Builder(this).setTitle(win?s("ثبت نتیجه: سود شد","Record result: WIN"):s("ثبت نتیجه: ضرر شد","Record result: LOSS")).setView(form).setNegativeButton(s("لغو","Cancel"),null).setPositiveButton(s("ثبت نتیجه","Save result"),(d,w)->{
            Double amount=number(pnl.getText().toString());
            if(amount==null || (win && amount<=0) || (!win && amount>=0)){
                new AlertDialog.Builder(this).setMessage(win?s("برای معامله برنده، سود را به‌صورت عدد مثبت وارد کن.","For a winning trade, enter a positive P/L amount."):s("برای معامله بازنده، ضرر را به‌صورت عدد منفی وارد کن.","For a losing trade, enter a negative P/L amount.")).setPositiveButton("OK",null).show();
                outcome(id,win); return;
            }
            db.updateOutcome(id,win?"WIN":"LOSS",String.format(Locale.US,"%.8f",amount),reason.getText().toString(),lesson.getText().toString(),pickedChart==null?null:pickedChart.toString());showTrades();
        }).show();
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==PICK_CHART&&resultCode==RESULT_OK&&data!=null){pickedChart=data.getData();try{getContentResolver().takePersistableUriPermission(pickedChart,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}}}
}
