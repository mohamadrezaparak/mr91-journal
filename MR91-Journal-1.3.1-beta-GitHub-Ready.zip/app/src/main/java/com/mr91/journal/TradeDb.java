package com.mr91.journal;

import android.content.*;
import android.database.*;
import android.database.sqlite.*;
import java.util.*;

public class TradeDb extends SQLiteOpenHelper {
    public TradeDb(Context c) { super(c, "mr91_journal.db", null, 1); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE trades(id INTEGER PRIMARY KEY AUTOINCREMENT,symbol TEXT,direction TEXT,status TEXT,currency TEXT,entry1 TEXT,entry2 TEXT,entryPrice TEXT,exitPrice TEXT,tp1 TEXT,tp2 TEXT,sl1 TEXT,sl2 TEXT,volume TEXT,leverage TEXT,pnl TEXT,reason TEXT,lesson TEXT,chartUri TEXT,createdAt TEXT)");
    }
    @Override public void onUpgrade(SQLiteDatabase db,int oldV,int newV) {}
    public long insert(Trade t) {
        ContentValues v = values(t); return getWritableDatabase().insert("trades",null,v);
    }
    public void updateOutcome(long id,String status,String pnl,String reason,String lesson,String chart) {
        ContentValues v=new ContentValues(); v.put("status",status); v.put("pnl",pnl); v.put("reason",reason); v.put("lesson",lesson); v.put("chartUri",chart);
        getWritableDatabase().update("trades",v,"id=?",new String[]{String.valueOf(id)});
    }
    public ArrayList<Trade> all() {
        ArrayList<Trade> out=new ArrayList<>(); Cursor c=getReadableDatabase().rawQuery("SELECT * FROM trades ORDER BY id DESC",null);
        try { while(c.moveToNext()){ Trade t=new Trade(); t.id=c.getLong(0); t.symbol=c.getString(1); t.direction=c.getString(2); t.status=c.getString(3); t.currency=c.getString(4); t.entry1=c.getString(5); t.entry2=c.getString(6); t.entryPrice=c.getString(7); t.exitPrice=c.getString(8); t.tp1=c.getString(9); t.tp2=c.getString(10); t.sl1=c.getString(11); t.sl2=c.getString(12); t.volume=c.getString(13); t.leverage=c.getString(14); t.pnl=c.getString(15); t.reason=c.getString(16); t.lesson=c.getString(17); t.chartUri=c.getString(18); t.createdAt=c.getString(19); out.add(t); } } finally { c.close(); } return out;
    }
    public int count(){ Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM trades",null); try{c.moveToFirst();return c.getInt(0);}finally{c.close();}}
    public int wins(){ Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM trades WHERE status='WIN'",null); try{c.moveToFirst();return c.getInt(0);}finally{c.close();}}
    public int losses(){ Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM trades WHERE status='LOSS'",null); try{c.moveToFirst();return c.getInt(0);}finally{c.close();}}
    public double totalPnl(){ Cursor c=getReadableDatabase().rawQuery("SELECT SUM(CAST(pnl AS REAL)) FROM trades WHERE pnl IS NOT NULL AND pnl!=''",null); try{c.moveToFirst();return c.isNull(0)?0:c.getDouble(0);}finally{c.close();}}
    public void delete(long id){getWritableDatabase().delete("trades","id=?",new String[]{String.valueOf(id)});}
    private ContentValues values(Trade t){
        ContentValues v=new ContentValues(); v.put("symbol",t.symbol);v.put("direction",t.direction);v.put("status","OPEN");v.put("currency",t.currency);
        v.put("entry1",t.entry1);v.put("entry2",t.entry2);v.put("entryPrice",t.entryPrice);v.put("exitPrice",t.exitPrice);
        v.put("tp1",t.tp1);v.put("tp2",t.tp2);v.put("sl1",t.sl1);v.put("sl2",t.sl2);v.put("volume",t.volume);v.put("leverage",t.leverage);
        v.put("createdAt",t.createdAt); return v;
    }
}
