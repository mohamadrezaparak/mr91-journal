package com.mr91.journal;

public class Trade {
    public long id;
    public String symbol, direction, status, currency, entry1, entry2, entryPrice, exitPrice;
    public String tp1, tp2, sl1, sl2, volume, leverage, pnl, reason, lesson, chartUri, createdAt;
}
